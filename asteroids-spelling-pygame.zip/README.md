# asteroids-spelling-pygame
My attempt vibe coding an arcade style game with gpt-oss:20b on Intel(R) Core(TM) i7-8750H CPU @ 2.20GHz, 2208 Mhz, 6 Core(s), 12 Logical Processor(s)