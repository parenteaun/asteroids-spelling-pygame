# game.py
import pygame
from pygame.locals import *
import math
import random

# ------------------------------------------------------------------
#  Utility helpers that all assets now use
# ------------------------------------------------------------------
SCREEN_W, SCREEN_H = 800, 600
#SCREEN_W, SCREEN_H = 800, 600

def wrap_position(pos):
    """Keeps a point inside the screen (wrap‑around)."""
    return (pos[0] % SCREEN_W, pos[1] % SCREEN_H)

# ------------------------------------------------------------------
#  Import the refactored assets
# ------------------------------------------------------------------
from assets.ship import Ship
from assets.asteroids import Asteroid
from assets.bullet import Bullet
from assets.collision import check_collisions
from assets.hearts import Hearts
from letterfrequency import build_frequency_list

# ------------------------------------------------------------------
#  Game‑state helpers
# ------------------------------------------------------------------
MAX_HEARTS = 8               # “lives” = hearts
TARGET_WORD = "CARS"         # what the player is trying to guess

def unique_letters_in_field(asteroids):
    return {a.letter for a in asteroids}

def choose_unique_letter(field_letters, guessed_letters):
    """
    Pick a letter from the frequency list that is **not** already on the field
    and **has not** been guessed yet.
    """
    pool = [c for c in build_frequency_list() if c not in field_letters and c not in guessed_letters]
    if pool:
        return random.choice(pool)
    # Fallback – if we run out of unique letters, just grab any
    return random.choice(build_frequency_list())

# ------------------------------------------------------------------
#  Main loop
# ------------------------------------------------------------------
def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
    pygame.display.set_caption("Day‑2 Challenge – Asteroids")

    clock = pygame.time.Clock()

    # ------------------------------------------------
    #  Initialise game objects
    # ------------------------------------------------
    ship = Ship((SCREEN_W/2, SCREEN_H/2), MAX_HEARTS)

    # 5 initial asteroids of random size/letter
    asteroids = [Asteroid(size=random.randint(1,3),
                          letter=choose_unique_letter(set(), set())) for _ in range(5)]

    guessed_letters = set()
    collected_word = ""

    hearts_disp = Hearts(ship.lives, pos=(10, SCREEN_H - 30))

    game_over = False
    win = False

    # ------------------------------------------------
    #  Main event/game‑loop
    # ------------------------------------------------
    while True:
        dt = clock.tick(60) / 1000.0   # delta‑time in seconds

        # --- 1️⃣  Event handling -------------------------------------------------
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                return

            # Close the persistent game‑over overlay on any key
            if game_over and event.type == KEYDOWN:
                game_over = False

        # --- 2️⃣  Update ---------------------------------------------------------
        if not game_over and not win:
            ship.handle_input(pygame.key.get_pressed())
            ship.update()

            # Update all asteroids
            for asteroid in asteroids:
                asteroid.update()

            # Collision handling – asteroids ↔ asteroids & ship
            check_collisions(asteroids, ship, guessed_letters, collect_letter=lambda l: None)

            # 3️⃣  Asteroid ↔ Bullet (inside the loop above or here)
            for bullet in ship.bullets[:]:
                for asteroid in asteroids[:]:
                    if asteroid.collide_with_point(bullet.pos):
                        # Bullet hits asteroid → damage=2
                        new_asteroids = asteroid.take_damage(2)
                        if new_asteroids:
                            asteroids.extend(new_asteroids)
                        if asteroid.size == 1 and asteroid.hit_points <= 0:
                            # Smallest asteroid killed – collect its letter
                            guessed_letters.add(asteroid.letter)
                            collected_word += asteroid.letter
                        if asteroid in asteroids:
                            asteroids.remove(asteroid)
                        ship.bullets.remove(bullet)
                        break

            # 4️⃣  Asteroid ↔ Ship (simple “damage”)
            for asteroid in asteroids:
                if asteroid.collide_with_point(ship.pos):
                    # damage rules: same size →1, 1‑size‑smaller →2, 2‑size‑smaller →4
                    diff = asteroid.size - 1   # ship has no “size”, treat as 1‑size “base”
                    if diff == 0:
                        dmg = 1
                    elif diff == 1:
                        dmg = 2
                    elif diff == 2:
                        dmg = 4
                    else:
                        dmg = 1
                    ship.lives -= dmg
                    if ship.lives < 0:
                        ship.lives = 0

        # --- 5️⃣  Win / Game‑over logic -----------------------------------------
        #  Player wins if all letters of TARGET_WORD have been guessed
        if set(TARGET_WORD) == guessed_letters:
            win = True

        if ship.lives <= 0:
            game_over = True

        # --- 6️⃣  Render ---------------------------------------------------------
        screen.fill((0,0,0))

        # Draw all asteroids
        for asteroid in asteroids:
            asteroid.draw(screen)

        # Draw the ship
        ship.draw(screen)

        # Draw hearts at the bottom
        hearts_disp.draw(screen)

        # Persistent overlay if game over / win
        if game_over:
            overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
            overlay.fill((0,0,0,180))
            font = pygame.font.SysFont(None, 48)
            txt = font.render("GAME OVER – Press any key", True, (255,255,255))
            txt_rect = txt.get_rect(center=(SCREEN_W/2, SCREEN_H/2))
            overlay.blit(txt, txt_rect)
            screen.blit(overlay, (0,0))

        if win:
            overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
            overlay.fill((0,0,0,180))
            font = pygame.font.SysFont(None, 48)
            txt = font.render("YOU WIN! – Press any key", True, (255,255,0))
            txt_rect = txt.get_rect(center=(SCREEN_W/2, SCREEN_H/2))
            overlay.blit(txt, txt_rect)
            screen.blit(overlay, (0,0))

        pygame.display.flip()

