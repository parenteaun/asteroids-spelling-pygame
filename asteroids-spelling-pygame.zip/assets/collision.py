# assets/collision.py
"""
What this does

Handles all “asteroid ↔ asteroid” collisions in one place.
Applies the damage table (1 / 2 / 4) depending on how many size steps smaller the defender is.
Keeps the ship from being “locked” by letting an asteroid that has hit another one simply bounce off.
"""

def check_collisions(asteroids, ship, guessed_letters, collect_letter):
    """
    *asteroids*  – list of Asteroid objects
    *ship*       – Ship object
    *guessed_letters* – set of letters already guessed
    *collect_letter*   – function(letter) called when a *smallest* asteroid dies
    """

    # 1️⃣  Asteroid ↔ Asteroid
    for i in range(len(asteroids)):
        a1 = asteroids[i]
        for j in range(i+1, len(asteroids)):
            a2 = asteroids[j]
            if a1.collide_with_point(a2.pos):
                # Determine damage based on size difference
                diff = a1.size - a2.size
                if diff == 0:
                    dmg = 1
                elif diff == 1:
                    dmg = 2
                elif diff == 2:
                    dmg = 4
                else:                # larger asteroid hits smaller by >2 – treat as 4
                    dmg = 4

                # Apply damage to *both* asteroids
                a1.hit_points -= dmg
                a2.hit_points -= dmg

                # Bounce – just reverse both velocity vectors
                a1.bounce_off(a2)

    # 2️⃣  Asteroid ↔ Ship
    for asteroid in asteroids:
        if asteroid.collide_with_point(ship.pos):
            # damage to the ship
            # Asteroid hitting ship follows the same table: same size → 1, 1 smaller → 2, 2 smaller → 4
            diff = asteroid.size - 1  # ship is “size‑1” by convention
            if diff == 0:
                dmg = 1
            elif diff == 1:
                dmg = 2
            elif diff == 2:
                dmg = 4
            else:
                dmg = 1
            ship.lives -= dmg
            if ship.lives < 0:
                ship.lives = 0

    # 3️⃣  Bullet ↔ Asteroid
    for bullet in ship.bullets[:]:
        for asteroid in asteroids[:]:
            if asteroid.collide_with_point(bullet.pos):
                # Bullet damage is 2
                new_asteroids = asteroid.take_damage(2)
                if new_asteroids:           # asteroid destroyed
                    if asteroid.size == 1:  # smallest
                        # new asteroid of *random* size – letter stays with the field, not collected
                        collect_letter(asteroid.letter)
                # Remove dead asteroid(s) from the field
                if asteroid.hit_points <= 0:
                    asteroids.remove(asteroid)
                # Remove the bullet after a hit
                if bullet in ship.bullets:
                    ship.bullets.remove(bullet)
                break   # stop checking other asteroids for this bullet
