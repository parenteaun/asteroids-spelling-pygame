# assets/hearts.py
import pygame

HEART_SIZE = 20
HEART_COLOR = (220, 20, 60)

class Hearts:
    """Draw a row of hearts equal to ship.lives."""
    def __init__(self, lives, pos):
        self.lives = lives
        self.pos = pos          # (x, y) top‑left corner

    def draw(self, surf):
        for i in range(self.lives):
            x = self.pos[0] + i * (HEART_SIZE + 4)
            y = self.pos[1]
            # simple heart
