# assets/ship.py
import pygame
from pygame.locals import *
import math
from game import wrap_position

# Ship constants – added for the reverse‑gear feature
SHIP_TURN_SPEED     = 6          # degrees per frame
SHIP_ACCEL          = 0.3
SHIP_DECEL          = 0.15
SHIP_FRICTION       = 0.98
SHIP_REVERSE_DECEL  = 0.05       # decel rate when in reverse gear
SHIP_BRAKE_THRESHOLD = 0.3      # seconds before gear flips to reverse

# Acute isosceles triangle: forward tip at the top, base angles 25°
SHIP_FWD_TIP_LEN = 25
SHIP_BASE_LEN   = 15

class Ship:
    def __init__(self, pos, lives):
        self.pos = pygame.Vector2(pos)
        self.vel = pygame.Vector2(0, 0)
        self.angle = 0                     # 0° points up
        self.lives = lives                 # hearts, not “hit‑points”
        self.bullets = []
        self.cooldown = 0

        # Reverse‑gear logic
        self.gear = "forward"              # "forward" or "reverse"
        self.back_key_pressed_time = None

    # ------------------ input ------------------
    def handle_input(self, keys):
        # Turning
        if keys[K_LEFT]:
            self.angle -= SHIP_TURN_SPEED
        if keys[K_RIGHT]:
            self.angle += SHIP_TURN_SPEED

        # Forward acceleration
        if keys[K_UP]:
            rad = math.radians(self.angle)
            thrust = pygame.Vector2(-math.sin(rad), -math.cos(rad))
            self.vel += thrust * SHIP_ACCEL
            self.gear = "forward"
            self.back_key_pressed_time = None

        # Backward key – decelerate or reverse
        if keys[K_DOWN]:
            if self.back_key_pressed_time is None:
                # start timing
                self.back_key_pressed_time = pygame.time.get_ticks()
            else:
                elapsed = (pygame.time.get_ticks() - self.back_key_pressed_time) / 1000.0
                if elapsed >= SHIP_BRAKE_THRESHOLD and self.vel.length() < 0.1:
                    # Reverse gear
                    self.gear = "reverse"
                    # push the ship backward (opposite to forward thrust)
                    rad = math.radians(self.angle)
                    thrust = pygame.Vector2(math.sin(rad), math.cos(rad))
                    self.vel += thrust * SHIP_DECEL
        else:
            self.back_key_pressed_time = None
            if self.gear == "reverse":
                # If we exit reverse gear, return to forward
                self.gear = "forward"

        # Shooting
        if self.cooldown <= 0 and keys[K_SPACE]:
            self.shoot()
            self.cooldown = 15   # frames

    # ------------------ actions ------------------
    def shoot(self):
        rad = math.radians(self.angle)
        tip = self.pos + pygame.Vector2(-math.sin(rad), -math.cos(rad)) * SHIP_FWD_TIP_LEN
        bullet_vel = pygame.Vector2(-math.sin(rad), -math.cos(rad)) * 12  # a little faster
        self.bullets.append(Bullet(tip, bullet_vel))

    # ------------------ updates ------------------
    def update(self):
        self.pos += self.vel
        self.vel *= SHIP_FRICTION
        self.pos = pygame.Vector2(wrap_position(self.pos))

        if self.cooldown > 0:
            self.cooldown -= 1

        for bullet in self.bullets[:]:
            bullet.update()
            if not (0 <= bullet.pos.x <= SCREEN_W and 0 <= bullet.pos.y <= SCREEN_H):
                self.bullets.remove(bullet)

    # ------------------ draw ------------------
    def draw(self, surf):
        rad = math.radians(self.angle)
        tip = pygame.Vector2(-math.sin(rad), -math.cos(rad)) * SHIP_FWD_TIP_LEN
        left = pygame.Vector2(math.sin(rad - math.radians(25)), math.cos(rad - math.radians(25))) * SHIP_BASE_LEN
        right = pygame.Vector2(math.sin(rad + math.radians(25)), math.cos(rad + math.radians(25))) * SHIP_BASE_LEN
        points = [self.pos + tip, self.pos + left, self.pos + right]
        pygame.draw.polygon(surf, (255, 255, 255), points)

        for bullet in self.bullets:
            bullet.draw(surf)
