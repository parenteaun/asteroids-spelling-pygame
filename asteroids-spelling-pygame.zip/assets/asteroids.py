# assets/asteroid.py
import pygame, random, math
from letterfrequency import build_frequency_list
from game import wrap_position

# Hit‑point table (size → hp)
SIZE_HITPOINTS = {3: 4, 2: 3, 1: 2}

# ------------------------------------------------------------------
#  Utility helpers that all assets now use
# ------------------------------------------------------------------
SCREEN_W, SCREEN_H = 800, 600

# Distinct colors per size (RGB)
SIZE_COLORS = {
    3: (70, 130, 180),   # steelblue
    2: (34, 139, 34),    # forestgreen
    1: (178, 34, 34)     # firebrick
}

class Asteroid:
    def __init__(self, pos=None, size=3, letter=None):
        self.size = size                        # 3 = large, 2 = medium, 1 = small
        self.hit_points = SIZE_HITPOINTS[size]
        self.color = SIZE_COLORS[size]
        self.radius = 30 * size                # scaled radius for visibility
        self.pos = pygame.Vector2(pos if pos else (random.randint(0, SCREEN_W), random.randint(0, SCREEN_H)))
        angle = random.uniform(0, 2 * math.pi)
        speed = random.uniform(0.5, 1.5) / size
        self.vel = pygame.Vector2(math.cos(angle), math.sin(angle)) * speed
        self.letter = letter or random.choice(build_frequency_list())
        self.surf = None

    def update(self):
        self.pos += self.vel
        self.pos = pygame.Vector2(wrap_position(self.pos))

    def draw(self, surf):
        if self.surf is None:
            size = self.radius * 2
            self.surf = pygame.Surface((size, size), pygame.SRCALPHA)
            pygame.draw.circle(self.surf, self.color, (self.radius, self.radius), self.radius)
            # Draw the letter inside the asteroid
            font = pygame.font.SysFont(None, int(self.radius))
            txt = font.render(self.letter, True, (255, 255, 255))
            txt_rect = txt.get_rect(center=(self.radius, self.radius))
            self.surf.blit(txt, txt_rect)
        surf.blit(self.surf, (self.pos.x - self.radius, self.pos.y - self.radius))

    def collide_with_point(self, point):
        return self.pos.distance_to(point) <= self.radius

    # Called when the asteroid takes damage; returns list of new asteroids if destroyed
    def take_damage(self, dmg):
        self.hit_points -= dmg
        if self.hit_points <= 0:
            # destroy: no letter collected; create a new random‑size asteroid
            return [Asteroid(size=random.randint(1,3))]
        return []

    # Collision bounce logic – simple reverse
    def bounce_off(self, other):
        # Compute a simple vector reversal (placeholder for proper physics)
        self.vel, other.vel = -self.vel, -other.vel
